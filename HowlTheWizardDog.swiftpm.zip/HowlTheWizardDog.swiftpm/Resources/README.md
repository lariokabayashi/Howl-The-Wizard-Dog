#  Howl The Wizard Dog

## About the game
### Howl The Wizard Dog is a game about emotional education where the goal is to show that identify and express your feeling can be something fun. The game starts with a Storytelling that gives the child the role of the hero of the story, then magical plants are introduced, which will have their powers unlocked if the child types a message in the text box with a feeling associated with the plant, and this action that will gradually save the world that is in chaos. 

### This playground should be run on on Xcode's IPad Pro (12.9-inch) simulator on macOS.

### All its illustrations are made by me, including the background, characters and other visual elements.

### The sound effects used in buttons and actions were downloaded in zapsplat (https://www.zapsplat.com), a platform with royalty free sounds.

### The datasets used for train the Sentiment predictor are from kaggle, the first one is from Praveen (https://www.kaggle.com/datasets/praveengovi/emotions-dataset-for-nlp) and changes were made in the dataset. 
### The Second one is from Paul Pandey (https://www.kaggle.com/datasets/parulpandey/emotion-dataset) and it is on public domain

### The text font is from https://www.dafont.com/pt/cutesy.font and the author gave freedom to use it for any content

### I hope you enjoy the playground!
